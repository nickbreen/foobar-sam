require "os/linux/global" if OS.linux?
