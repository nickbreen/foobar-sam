PYTHON_VIRTUALENV_URL =
  "https://files.pythonhosted.org/packages/37/db" \
  "/89d6b043b22052109da35416abc3c397655e4bd3cff031446ba02b9654fa" \
  "/virtualenv-16.4.3.tar.gz".freeze
PYTHON_VIRTUALENV_SHA256 =
  "984d7e607b0a5d1329425dd8845bd971b957424b5ba664729fab51ab8c11bc39".freeze
