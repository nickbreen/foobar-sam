require "cask/artifact/moved"

module Cask
  module Artifact
    class Dictionary < Moved
    end
  end
end
