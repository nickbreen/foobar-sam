require "cask/artifact/abstract_flight_block"

module Cask
  module Artifact
    class PreflightBlock < AbstractFlightBlock
    end
  end
end
