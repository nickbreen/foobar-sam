require "cask/artifact/moved"

module Cask
  module Artifact
    class App < Moved
    end
  end
end
