require "cask/artifact/abstract_flight_block"

module Cask
  module Artifact
    class PostflightBlock < AbstractFlightBlock
    end
  end
end
