require "cask/artifact/moved"

module Cask
  module Artifact
    class ScreenSaver < Moved
    end
  end
end
