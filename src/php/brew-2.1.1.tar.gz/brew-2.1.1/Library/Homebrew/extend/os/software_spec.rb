require "extend/os/linux/software_spec" if OS.linux?
