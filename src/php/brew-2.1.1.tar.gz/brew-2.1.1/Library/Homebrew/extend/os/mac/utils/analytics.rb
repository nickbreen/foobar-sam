module Utils
  module Analytics
    class << self
      def custom_prefix_label
        "non-/usr/local".freeze
      end
    end
  end
end
